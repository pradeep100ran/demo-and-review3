<!DOCTYPE html>
<html>
<head>
    <title>Push Notification Shower</title>
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('service-worker.js')
                .then(function(registration) {
                    console.log('Service Worker registered:', registration);
                })
                .catch(function(error) {
                    console.error('Error registering Service Worker:', error);
                });
        }

        function subscribeToPush() {
            if ('serviceWorker' in navigator && 'PushManager' in window) {
                navigator.serviceWorker.ready.then(function(registration) {
                    registration.pushManager.getSubscription().then(function(subscription) {
                        if (subscription) {
                            console.log('Already subscribed to push notifications:', subscription);
                        } else {
                            registration.pushManager.subscribe({
                                userVisibleOnly: true,
                                applicationServerKey: urlBase64ToUint8Array('AIzaSyBjLCu38CNTDPxOfH0gmnrw1kUG6dpRRhw')
                            })
                                .then(function(newSubscription) {
                                    console.log('Push subscription:', newSubscription);
                                    // Send the subscription information to your server
                                })
                                .catch(function(error) {
                                    console.error('Error subscribing to push notifications:', error);
                                });
                        }
                    });
                });
            }
        }
function urlBase64ToUint8Array(base64String) {
            var padding = '='.repeat((4 - base64String.length % 4) % 4);
            var base64 = (base64String + padding)
                .replace(/\-/g, '+')
                .replace(/_/g, '/');

            var base64Decoded = decodeBase64(base64);
            var outputArray = new Uint8Array(base64Decoded);

            return outputArray;
        }

        function decodeBase64(base64) {
            var characters =
                'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
            var result = [];

            var buffer = 0;
            var bufferLength = 0;

            for (var i = 0; i < base64.length; i++) {
                if (base64[i] === '=') {
                    break;
                }

                var charIndex = characters.indexOf(base64[i]);

                if (charIndex === -1) {
                    throw new Error('Invalid base64 string');
                }

                buffer = (buffer << 6) | charIndex;
                bufferLength += 6;

                if (bufferLength >= 8) {
                    result.push((buffer >> (bufferLength - 8)) & 255);
                    bufferLength -= 8;
                }
            }

            return result;
        }
    </script>
</head>
<body>
    <button onclick="subscribeToPush()">Subscribe to Push Notifications</button>
</body>
</html>