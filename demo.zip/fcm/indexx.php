<!DOCTYPE html>
<html>
<head>
  <title>FCM Push Notifications</title>
  <script src="https://www.gstatic.com/firebasejs/8.6.1/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/8.6.1/firebase-messaging.js"></script>
</head>
<body>
  <h1>FCM Push Notifications</h1>
<h1 id="token">Token here</h1>
  <script>
    // Replace the values with your Firebase configuration
    const fire = {
      apiKey: "YOUR_API_KEY",
      authDomain: "YOUR_AUTH_DOMAIN",
      projectId: "YOUR_PROJECT_ID",
      appId: "YOUR_APP_ID",
    };
    
    
const firebaseConfi= {
apiKey: "AIzaSyDkp-_VHVhxZmK7QKaACCtfKVkl6DYKy1Q",
authDomain: "notification-f9199.firebaseapp.com",
projectId: "notification-f9199",
appId: "1:545254970810:web:bcfbe6bc328082d5557983"
   };
   
   
   
const firebaseConfig = {
    apiKey: "AIzaSyDkp-_VHVhxZmK7QKaACCtfKVkl6DYKy1Q",
    authDomain: "notification-f9199.firebaseapp.com",
    projectId: "notification-f9199",
    storageBucket: "notification-f9199.appspot.com",
    messagingSenderId: "545254970810",
    appId: "1:545254970810:web:bcfbe6bc328082d5557983",
    measurementId: "G-8T4JX0NHKB"
  };   
   
   
    firebase.initializeApp(firebaseConfig);
    const messaging = firebase.messaging();


    messaging
      .requestPermission()
      .then(() => {
        console.log("Notification permission granted.");
        return messaging.getToken();
      })
      .then((token) => {
        console.log("FCM token:", token);
        
document.getElementById('token').innerHTML=token;
        // Send this token to your server to associate it with the user.
      })
      .catch((error) => {
        console.log("Unable to get permission to notify.", error);
      });

    messaging.onMessage((payload) => {
      console.log("Message received:", payload);
      // Handle the notification and update the UI as needed.
    });
  </script>
</body>
</html>