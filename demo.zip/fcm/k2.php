<?php
    $url = "https://fcm.googleapis.com/fcm/send";
$token = "d8JJjqnWTnu7iz3SQJfWkC:APA91bFxdTOe-n4VoR_ATpWnOQl0b0CfOwDsN83b9gUuUoCblPIBQ0neCFs5AJh_qYniK59LWGP0sc3HoVQvqcTqShq3XJTNIwTwbrvVpUfH0NSGpWuh-9Ao7ZmRmlQQW4njkmJ2JRry";
$serverKey = 'AAAAucpu21Y:APA91bEYxJ6XGquZzAxqJnyUYeSwi7ocOWO4iJwi676vXnRXrDn-TazsJmESzQHHv5Dx2OO3HFOk5moxzpvEPCMCv3UA5ZopDnVFBK6lOeE1qWQugDVabmN229DAXd3G7tdul7mmlYpF';
    
//$token='dz-Dn23EnzaMVyDu8VBbii:APA91bFdD2dbOVwCd67UB3HGYxXh9ZJymw66CXa91ceqpjbHUS_jSPU5dMz99qTn2eh9rCBQO1IjCH_suM7k1VeaHJB8DWqF9azXtvh4lqnYigTQdC7OgM0ud4Hx-2YoArHgcnAkNciL';

//$token='didYxcE-PuYnr1MZkTCw8R:APA91bFKaCtdiInVJLbWIoLWLKyqevCi3qARq6L4oChRivLbdE9X2OQyIwjqiqM5loA9j_le-5_mNSPZvIZ_ikSE3gkQNJalHCT_o0yymeMawMWNzQ97WQeIiNIT0jHtsQRJWteue-8X';

    
//$serverKey='AAAAfvO6lbo:APA91bF0GxqnTZFxYyQBVOIb4CuBNDVNixs9gyhVlH-VTLEvvzriw2LvjOSRUKEJSqPmKDU_RjR0BLClBKm1wd-hr5mbD6LAYtziWNSOs_Db59Y9CqRd2GIVcfWf-_BMmDttJQ8iOXhq';
    
    $title = "Notification title";
    $body = "Hello I am from Your php server";
    $notification = array('title' =>$title , 'body' => $body, 'sound' => 'default', 'badge' => '2');
    $arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
    $json = json_encode($arrayToSend);
    $headers = array();
    $headers[] = 'Content-Type: application/json';
    $headers[] = 'Authorization: key='. $serverKey;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
    //Send the request
    $response = curl_exec($ch);
    //Close request
    if ($response === FALSE) {
    die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);
?>