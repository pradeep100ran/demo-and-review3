<?php

$endpoint = 'https://fcm.googleapis.com/fcm/send';
$serverKey = 'AAAAfvO6lbo:APA91bFnnzlMl0rRAMFFed7fjVa0urkSv9I76oDyfgCOD_O98hySNL_BclbuhQQidDYC0nUQenLAcIjIfHXkJJOtPk8spU5pFjaSLJVZuozlWMl4xtk6MnUlFo9qxc7vTkUewEa7NWcB'; // Replace with your FCM server key
$endpointUrl = 'https://fcm.googleapis.com/fcm/send';

$subscription = [
    'endpoint' => 'https://fcm.googleapis.com/fcm/send/d4O1q2A-1QY:APA91bE5oBllZbF3c34Sb8Rm1MR4sFw3GDPjubZH60XQeEoEnfpSnkU27j-JKqu54kyv2rY6UFiqSvOLTQjcotR-pyZZMXH4QPZYa8tBG331s2RwhjPtwpNZC08emeRyLYgU8caboIP4',
    'keys' => [
        'p256dh' => 'BHZEG5_9s-vFIlYgy92Ya5uXEMpAa-6Lc3hWs6pL_W_W-ewOmpCRhiRnVDydS6dSjjeBH1uMnrivCnYdWpnrBwk',
        'auth' => 'Lp_Uii9Jso3dzM6R2lJoaQ',
    ],
];

$notification = [
    'title' => 'Hello from PHP!',
    'body' => 'This is the body of the notification.',
];

$data = [
    'notification' => $notification,
    'webpush' => [
        'headers' => [
            'TTL' => '300', // Time-to-Live of the notification in seconds
        ],
        'fcm_options' => [
            'link' => 'https://example.com', // URL to open when user clicks on the notification
        ],
        'subscription' => $subscription,
    ],
];

$headers = [
    'Content-Type: application/json',
    'Authorization: key=' . $serverKey,
];

$ch = curl_init($endpointUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
$response = curl_exec($ch);
curl_close($ch);

echo 'Push notification sent successfully!';

?>