importScripts('https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js');
importScripts('https://www.gstatic.com/firebasejs/10.0.0/firebase-messaging.js');


const firebaseConfig = {
  apiKey: "AIzaSyDkp-_VHVhxZmK7QKaACCtfKVkl6DYKy1Q",
  authDomain: "notification-f9199.firebaseapp.com",
  projectId: "notification-f9199",
  storageBucket: "notification-f9199.appspot.com",
  messagingSenderId: "545254970810",
  appId: "1:545254970810:web:bcfbe6bc328082d5557983",
  measurementId: "G-8T4JX0NHKB"
};

firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

self.addEventListener('push', function(event) {
  // Handle push notifications here
  // ...
});

self.addEventListener('notificationclick', function(event) {
  // Handle notification clicks here
  // ...
});