<?php
$ch = curl_init();

//curl_setopt($ch, CURLOPT_URL, 'https://demo-and-review.000webhostapp.com/apis/action.php?action=new_order');
curl_setopt($ch, CURLOPT_URL, 'https://flawless-valley-harbor.glitch.me/send-message/123');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "{\"message\":\"16863336932212343989\"}");

//,\"login_hash\":\"3b2979ae075bac9a9e2401cbc7d969e8\",\"basket_id\":1,\"title_hash\":\"4824d7b6082f526d738252473682fa4d\",\"price\":\"125.20\",\"price_hash\":\"b565a52fa70bf11df0a61070320a2585\",\"timestamp\":1689321666,\"quantity\":\"50\",\"type\":\"SELL\"}]");
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

$headers = array();
$headers[] = 'Authority: demo-and-review.000webhostapp.com';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7';
$headers[] = 'Content-Type: application/json';
$headers[] = 'Origin: https://demo-and-review.000webhostapp.com';
$headers[] = 'Referer: https://demo-and-review.000webhostapp.com/';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"107\", \"Not=A?Brand\";v=\"24\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 11; M2101K7AI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
echo($result);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
?>