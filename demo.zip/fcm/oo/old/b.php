<?php
$ch = curl_init();

curl_setopt($ch, CURLOPT_URL, 'https://zerodha.com/margin-calculator/SPAN');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, "action=calculate&exchange%5B%5D=NFO&product%5B%5D=OPT&scrip%5B%5D=NIFTY23JUL&option_type%5B%5D=CE&strike_price%5B%5D=19500&qty%5B%5D=50&trade%5B%5D=sell&exchange%5B%5D=NFO&product%5B%5D=OPT&scrip%5B%5D=NIFTY23JUL&option_type%5B%5D=PE&strike_price%5B%5D=19550&qty%5B%5D=50&trade%5B%5D=sell");
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');

$headers = array();
$headers[] = 'Authority: zerodha.com';
$headers[] = 'Accept: application/json, text/javascript, */*; q=0.01';
$headers[] = 'Accept-Language: en-IN,en-GB;q=0.9,en-US;q=0.8,en;q=0.7';
$headers[] = 'Content-Type: application/x-www-form-urlencoded; charset=UTF-8';
$headers[] = 'Cookie: _cfuvid=bOlzUqvjubdn7rt1uPT8eFeF3yyxZ.48nFfIQMuO2Y4-1689495946869-0-604800000; _pk_id.2.1556=c2928f65642fdf4e.1689496346.; _pk_ses.2.1556=1; ref=zerodha';
$headers[] = 'Origin: https://zerodha.com';
$headers[] = 'Referer: https://zerodha.com/';
$headers[] = 'Sec-Ch-Ua: \"Chromium\";v=\"107\", \"Not=A?Brand\";v=\"24\"';
$headers[] = 'Sec-Ch-Ua-Mobile: ?1';
$headers[] = 'Sec-Ch-Ua-Platform: \"Android\"';
$headers[] = 'Sec-Fetch-Dest: empty';
$headers[] = 'Sec-Fetch-Mode: cors';
$headers[] = 'Sec-Fetch-Site: same-origin';
$headers[] = 'User-Agent: Mozilla/5.0 (Linux; Android 11; M2101K7AI) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Mobile Safari/537.36';
$headers[] = 'X-Requested-With: XMLHttpRequest';
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($ch);
echo($result);
if (curl_errno($ch)) {
    echo 'Error:' . curl_error($ch);
}
curl_close($ch);
?>