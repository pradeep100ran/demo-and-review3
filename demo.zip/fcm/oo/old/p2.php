<?php

$endpoint = 'https://fcm.googleapis.com/fcm/send';
$serverKey = 'AAAAucpu21Y:APA91bEYxJ6XGquZzAxqJnyUYeSwi7ocOWO4iJwi676vXnRXrDn-TazsJmESzQHHv5Dx2OO3HFOk5moxzpvEPCMCv3UA5ZopDnVFBK6lOeE1qWQugDVabmN229DAXd3G7tdul7mmlYpF'; // Replace with your FCM server key
$endpointUrl = 'https://fcm.googleapis.com/fcm/send';

$subscription = [
    'endpoint' => 'https://fcm.googleapis.com/fcm/send/d8JJjqnWTnu7iz3SQJfWkC:APA91bFxdTOe-n4VoR_ATpWnOQl0b0CfOwDsN83b9gUuUoCblPIBQ0neCFs5AJh_qYniK59LWGP0sc3HoVQvqcTqShq3XJTNIwTwbrvVpUfH0NSGpWuh-9Ao7ZmRmlQQW4njkmJ2JRry',
    'keys' => [
        'p256dh' => 'BHZEG5_9s-vFIlYgy92Ya5uXEMpAa-6Lc3hWs6pL_W_W-ewOmpCRhiRnVDydS6dSjjeBH1uMnrivCnYdWpnrBwk',
        'auth' => 'Lp_Uii9Jso3dzM6R2lJoaQ',
    ],
];

$notification = [
    'title' => 'Hello from PHP!',
    'body' => 'This is the body of the notification.',
];

$data = [
    'notification' => $notification,
    'webpush' => [
        'headers' => [
            'TTL' => '300', // Time-to-Live of the notification in seconds
        ],
        'fcm_options' => [
            'link' => 'https://example.com', // URL to open when user clicks on the notification
        ],
        'subscription' => $subscription,
    ],
];

$headers = [
    'Content-Type: application/json',
    'Authorization: key=' . $serverKey,
];

$ch = curl_init($endpointUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
$response = curl_exec($ch);
curl_close($ch);

echo 'Push notification sent successfully!';

?>