<?php
$url = "https://fcm.googleapis.com/fcm/send";
$token = "d8JJjqnWTnu7iz3SQJfWkC:APA91bFxdTOe-n4VoR_ATpWnOQl0b0CfOwDsN83b9gUuUoCblPIBQ0neCFs5AJh_qYniK59LWGP0sc3HoVQvqcTqShq3XJTNIwTwbrvVpUfH0NSGpWuh-9Ao7ZmRmlQQW4njkmJ2JRry";
//$token='d4O1q2A-1QY:APA91bE5oBllZbF3c34Sb8Rm1MR4sFw3GDPjubZH60XQeEoEnfpSnkU27j-JKqu54kyv2rY6UFiqSvOLTQjcotR-pyZZMXH4QPZYa8tBG331s2RwhjPtwpNZC08emeRyLYgU8caboIP4';
   // $serverKey = 'AAAAucpu21Y:APA91bEYxJ6XGquZzAxqJnyUYeSwi7ocOWO4iJwi676vXnRXrDn-TazsJmESzQHHv5Dx2OO3HFOk5moxzpvEPCMCv3UA5ZopDnVFBK6lOeE1qWQugDVabmN229DAXd3G7tdul7mmlYpF';
$serverKey='AAAAfvO6lbo:APA91bF0GxqnTZFxYyQBVOIb4CuBNDVNixs9gyhVlH-VTLEvvzriw2LvjOSRUKEJSqPmKDU_RjR0BLClBKm1wd-hr5mbD6LAYtziWNSOs_Db59Y9CqRd2GIVcfWf-_BMmDttJQ8iOXhq';   
    
    $title = "Notification title";
    $body = "Hello I am from Your php server";
    $notification = array('title' =>$title , 'body' => $body, 'sound' => 'default', 'badge' => '1');
    $arrayToSend = array('to' => $token, 'notification' => $notification,'priority'=>'high');
    $json = json_encode($arrayToSend);
    $headers = array();
    $headers[] = 'Content-Type: application/json';
    $headers[] = 'Authorization: key='. $serverKey;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST,"POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $json);
    curl_setopt($ch, CURLOPT_HTTPHEADER,$headers);
    //Send the request
    $response = curl_exec($ch);
    //Close request
    if ($response === FALSE) {
    die('FCM Send Error: ' . curl_error($ch));
    }
    curl_close($ch);
?>