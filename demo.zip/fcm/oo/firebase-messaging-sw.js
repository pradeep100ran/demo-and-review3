const firebaseConfig = {
    apiKey: "AIzaSyDkp-_VHVhxZmK7QKaACCtfKVkl6DYKy1Q",
    authDomain: "notification-f9199.firebaseapp.com",
    projectId: "notification-f9199",
    storageBucket: "notification-f9199.appspot.com",
    messagingSenderId: "545254970810",
    appId: "1:545254970810:web:bcfbe6bc328082d5557983",
    measurementId: "G-8T4JX0NHKB"
  };



firebase.initializeApp(firebaseConfig);

const messaging = firebase.messaging();

messaging.onBackgroundMessage(function(payload) {
  console.log('Received background message:', payload);
  // Customize the handling of the background message payload
  // You can show a notification, update local data, etc.
  const notificationTitle = payload.notification.title;
  const notificationOptions = {
    body: payload.notification.body,
    icon: payload.notification.icon,
  };
  
  self.registration.showNotification(notificationTitle, notificationOptions);
});