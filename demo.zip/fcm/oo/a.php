<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Firebase Device Token Generation</title>
</head>
<body>
  <h1>Firebase Device Token Generation</h1>
  
  <script type="module">
    // Import the functions you need from the SDKs you need
    import { initializeApp } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js";
    import { getMessaging, getToken } from "https://www.gstatic.com/firebasejs/10.0.0/firebase-messaging.js";
  
    // Your web app's Firebase configuration
    // For Firebase JS SDK v7.20.0 and later, measurementId is optional
    const firebaseConfig = {
      apiKey: "AIzaSyDkp-_VHVhxZmK7QKaACCtfKVkl6DYKy1Q",
      authDomain: "notification-f9199.firebaseapp.com",
      projectId: "notification-f9199",
      storageBucket: "notification-f9199.appspot.com",
      messagingSenderId: "545254970810",
      appId: "1:545254970810:web:bcfbe6bc328082d5557983",
      measurementId: "G-8T4JX0NHKB"
    };
  
    // Initialize Firebase
    const app = initializeApp(firebaseConfig);
    const messaging = getMessaging(app);
  
    // Generate device token
    getToken(messaging, { vapidKey: 'BMv_P4TN3WUuY6B929_cr-vrmNUFc4mnmu87QmiwTKeqPBZ8oVnZGWQ2nq5qrPrYuwtx04lJhOSh_CJEgLAVBjM' })
      .then(function(token) {
        console.log('Device token:', token);
        // Send the device token to your server or use it to send FCM notifications directly
      })
      .catch(function(error) {
        console.log('Error getting device token:', error);
      });
  </script>
</body>
</html>