<!DOCTYPE html>
<html>
<head>
  <title>Generate Device Token</title>
  <script src="https://www.gstatic.com/firebasejs/10.0.0/firebase-app.js"></script>
  <script src="https://www.gstatic.com/firebasejs/10.0.0/firebase-messaging.js"></script>
</head>
<body>
  <h1>Generate Device Token</h1>
  <button onclick="generateToken()">Generate Token</button>
  <p id="token"></p>

  <script>
    const firebaseConfig = {
      apiKey: "AIzaSyDkp-_VHVhxZmK7QKaACCtfKVkl6DYKy1Q",
      authDomain: "notification-f9199.firebaseapp.com",
      projectId: "notification-f9199",
      storageBucket: "notification-f9199.appspot.com",
      messagingSenderId: "545254970810",
      appId: "1:545254970810:web:bcfbe6bc328082d5557983",
      measurementId: "G-8T4JX0NHKB"
    };

    // Initialize Firebase
    firebase.initializeApp(firebaseConfig);

    // Retrieve the Messaging object
    const messaging = firebase.messaging();

    function generateToken() {
      messaging
        .requestPermission()
        .then(() => messaging.getToken())
        .then((token) => {
          document.getElementById("token").textContent = "Device Token: " + token;
          console.log("Device token:", token);
        })
        .catch((error) => {
          console.log("Error occurred while requesting permission or retrieving token:", error);
        });
    }
  </script>
</body>
</html>