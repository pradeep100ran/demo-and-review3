<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/admin/config.php';
$id=$_GET['id'];
if($id=='token'){
$sql='DELETE FROM token';
mysqli_query($link,$sql); 
}
if($id=='open'){
$sql='DELETE FROM openposition';
mysqli_query($link,$sql);
}
if($id=='close'){
$sql='DELETE FROM closeposition';
mysqli_query($link,$sql);
}
if($id=='orders'){
$sql='DELETE FROM orders';
mysqli_query($link,$sql);
}
if($id=='watchlist'){
$sql='DELETE FROM watchlist';
mysqli_query($link,$sql);
}
if($id=='basket'){
$sql='DELETE FROM basket';
mysqli_query($link,$sql);
}
if($id=='wipeout'){
$sql='DELETE FROM basket';
mysqli_query($link,$sql);
$sql='DELETE FROM closeposition';
mysqli_query($link,$sql);
$sql='DELETE FROM openposition';
mysqli_query($link,$sql);
$sql='DELETE FROM orders';
mysqli_query($link,$sql);
$sql='DELETE FROM token';
//mysqli_query($link,$sql);
//$sql='DELETE FROM user';
mysqli_query($link,$sql);
$sql='DELETE FROM watchlist';
mysqli_query($link,$sql);
}
if($id=='wipeoutfull'){
$sql='DELETE FROM basket';
mysqli_query($link,$sql);
$sql='DELETE FROM closeposition';
mysqli_query($link,$sql);
$sql='DELETE FROM openposition';
mysqli_query($link,$sql);
$sql='DELETE FROM orders';
mysqli_query($link,$sql);
$sql='DELETE FROM token';
mysqli_query($link,$sql);
$sql='DELETE FROM user';
mysqli_query($link,$sql);
$sql='DELETE FROM watchlist';
mysqli_query($link,$sql);
}
header("Location: /admin/index.php");
exit();
?>