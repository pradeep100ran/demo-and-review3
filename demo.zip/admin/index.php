<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once $_SERVER['DOCUMENT_ROOT'].'/admin/config.php';

$old = array();
$sql = 'SELECT title_hash, exchange, segment, title, instrument_token FROM token';
$query = mysqli_query($link, $sql);

if (mysqli_num_rows($query) > 0) {
    while ($row = $query->fetch_assoc()) {
        $title = $row["title"];
        $title_hash = $row["title_hash"];
        $instrument_token = $row["instrument_token"];
        $iii = $instrument_token;
        array_push($old, $iii);
    }
}

$db_total = sizeof($old);
$db_unique = sizeof(array_unique($old));

$root = $_SERVER['DOCUMENT_ROOT'];
$nfo_size = round(filesize($root.'/admin/full_full.txt')/1024, 2)."KB";
$nfo_time = date("h:i:s A", filemtime($root."/admin/full_full.txt")+19800);
$nfo_date = date("d-M-Y", filemtime($root."/admin/full_full.txt")+19800);

$fp = fopen($root."/admin/full_full.txt", "r");
$count = 0;

while ($line = fgets($fp)) {
    // Use strip_tags to remove HTML tags if needed
    $line = strip_tags($line);
    $count++;
}

fclose($fp);

$nfo = $nfo_size."<br>Total Token On Server = ".($count-1)."<br>Total Token in Database = ".$db_total."<br>Unique Token In Database = ".$db_unique."<br>Last Download = ".$nfo_time."  ".$nfo_date;
?>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css?family=Roboto:400,700" rel="stylesheet">
  <style>
    body {
      background-color: #f5f5f5;
      font-family: 'Roboto', sans-serif;
    }
    
    .container {
      max-width: 500px;
      margin: 0 auto;
      padding: 20px;
    }
    
    .title {
      background-color: #117A65;
      color: #fff;
      padding: 10px;
      margin-bottom: 20px;
      text-align: center;
      font-size: 18px;
      font-weight: 700;
    }
    
    .btn-group {
      margin-bottom: 10px;
    }
    
    .btn-success {
      background: #4CAF50;
      background:white;
      color:#33a69a;
      border-color: #4CAF5000;
      font-weight:700;
    }
    
     .btn-successs {
      color:#33a69a;
      text-align: center;
      border-color: #4CAF5000;
      font-weight:800;
    }
    
    .btn-info {
      background:white;
      color: #2196F3;
      border-color: #2196F300;
      font-weight:700;
    }
    
    .btn-danger {
      background:white;
      color: #FF004D;
      border-color: #F4433600;
      font-weight:700;
    }
    
    .btn-group-justified .btn {
      border-radius: 4px;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="title">Admin Panel</div>
    <div class="btn-group btn-group-justified">
      <div href="#" class="btn-successs">Token file size on Server <?php echo $nfo; ?></div>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/smart_token.php?refer=1" class="btn btn-info">Download and Update Token</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=token" class="btn btn-danger">Delete Data from Database</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=open" class="btn btn-success">Delete All Open Positions</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=close" class="btn btn-info">Delete All Closed Positions</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=orders" class="btn btn-danger">Delete All Orders</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=basket" class="btn btn-success">Delete Basket</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=watchlist" class="btn btn-info">Delete Watchlist</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=wipeout" class="btn btn-info">Delete Everything on Server</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/admin/delete.php?id=wipeoutfull" class="btn btn-danger">Delete Everything on Server(User Also)</a>
    </div>
    <div class="btn-group btn-group-justified">
      <a href="/apis/auto_sq_off.php" class="btn btn-success">Sq off all Expired Position</a>
    </div>
  </div>
</body>
</html>