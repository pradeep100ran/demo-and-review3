<?php
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'id19957279_fnodata');
define('DB_PASSWORD', 'Pradeep@123#');
define('DB_NAME', 'id19957279_fno');
$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
if($link === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
?>