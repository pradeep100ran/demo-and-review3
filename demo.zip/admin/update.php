<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once $_SERVER['DOCUMENT_ROOT'].'/admin/config.php';
$old = array();
$sql = 'SELECT * FROM token';
$query = mysqli_query($link, $sql);
if (mysqli_num_rows($query) > 0) {
while ($row = $query->fetch_assoc()) {
$title = $row["title"];
$title_hash = $row["title_hash"];
$exchange = $row["exchange"];
$iii = $exchange;
array_push($old, $iii);
  }
}
$xxxx = $old;
$db_total = sizeof($xxxx);
$db_unique = sizeof(array_unique($xxxx));
var_dump(json_encode(array_unique($xxxx)));
//echo($db_unique);
    ?>