<?php

//CREATE TABLE `basket` ( `id` int(11) NOT NULL AUTO_INCREMENT, `userid` varchar(255) NOT NULL, `basket_id` varchar(255) NOT NULL, `title` varchar(255) NOT NULL, `description` varchar(255) NOT NULL, `time` varchar(255) NOT NULL, PRIMARY KEY (`id`) ) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

//CREATE TABLE `closeposition` ( `userid` varchar(255) NOT NULL, `basket_id` varchar(255) NOT NULL, `title` varchar(255) NOT NULL, `title_hash` varchar(255) NOT NULL, `exchange` varchar(255) NOT NULL, `buy_quantity` varchar(255) NOT NULL, `buy_value` varchar(255) NOT NULL, `sell_quantity` varchar(255) NOT NULL, `sell_value` varchar(255) NOT NULL, `buy_time` varchar(255) NOT NULL, `sell_time` varchar(255) NOT NULL, `flow` varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

//CREATE TABLE `openposition` ( `userid` varchar(255) NOT NULL, `basket_id` varchar(255) NOT NULL, `title` varchar(255) NOT NULL, `title_hash` varchar(255) NOT NULL, `buy_quantity` varchar(255) NOT NULL, `buy_value` varchar(255) NOT NULL, `sell_quantity` varchar(255) NOT NULL, `sell_value` varchar(255) NOT NULL, `ltp` varchar(255) NOT NULL, `expiry_timestamp` varchar(255) NOT NULL, `last_updated` varchar(255) NOT NULL, `time` varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

//CREATE TABLE `orders` ( `userid` varchar(255) NOT NULL, `basket_id` varchar(255) NOT NULL, `order_number` varchar(255) NOT NULL, `order_type` varchar(255) NOT NULL, `status` varchar(255) NOT NULL, `title` varchar(255) NOT NULL, `title_hash` varchar(255) NOT NULL, `exchange` varchar(255) NOT NULL, `buy_quantity` varchar(255) NOT NULL, `buy_value` varchar(255) NOT NULL, `sell_quantity` varchar(255) NOT NULL, `sell_value` varchar(255) NOT NULL, `time` varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

//CREATE TABLE `token` ( `title` varchar(255) NOT NULL, `title_hash` varchar(255) NOT NULL, `instrument_token` varchar(255) NOT NULL, `exchange_token` varchar(255) NOT NULL, `tradingsymbol` varchar(255) NOT NULL, `name` varchar(255) NOT NULL, `last_price` varchar(255) NOT NULL, `expiry` varchar(255) NOT NULL, `strike` varchar(255) NOT NULL, `tick_size` varchar(255) NOT NULL, `lot_size` varchar(255) NOT NULL, `instrument_type` varchar(255) NOT NULL, `segment` varchar(255) NOT NULL, `exchange` varchar(255) NOT NULL, `expiry_timestamp` varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

//CREATE TABLE `user` ( `userid` varchar(255) NOT NULL, `name` varchar(255) NOT NULL, `number` varchar(255) NOT NULL, `email` varchar(200) DEFAULT NULL, `password` varchar(255) NOT NULL, `funds` varchar(255) NOT NULL, `balance` varchar(255) NOT NULL, `expiry` varchar(255) NOT NULL, `trial` varchar(255) NOT NULL, `time` int(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

//CREATE TABLE `watchlist` ( `userid` varchar(255) NOT NULL, `basket_id` varchar(255) NOT NULL, `watchlist_id` varchar(255) NOT NULL, `title` varchar(255) NOT NULL, `title_hash` varchar(255) NOT NULL, `kite_title_hash` varchar(255) NOT NULL, `strike` varchar(255) NOT NULL, `lot_size` varchar(255) NOT NULL, `instrument_type` varchar(255) NOT NULL, `segment` varchar(255) NOT NULL, `exchange` varchar(255) NOT NULL, `spot_token` varchar(255) NOT NULL, `expiry_timestamp` varchar(255) NOT NULL ) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
//

?>

<?php
include 'config.php';

// Get list of tables in the current database
$tablesResult = mysqli_query($link, "SHOW TABLES");
$tables = mysqli_fetch_all($tablesResult);

// Loop through each table and generate CREATE TABLE query
$createTableQueries = [];
foreach ($tables as $table) {
    $tableName = $table[0];

    // Retrieve table structure
    $tableStructureResult = mysqli_query($link, "SHOW CREATE TABLE $tableName");
    $tableStructure = mysqli_fetch_assoc($tableStructureResult);
    $createTableQueries[] = $tableStructure['Create Table'];
}

// Close the connection
mysqli_close($link);

// Output CREATE TABLE queries
foreach ($createTableQueries as $query) {
    echo $query . ";\n\n";
    
    echo('<br><br>');
}
?>