<?php
$refer=0;
if(isset($_GET['refer'])){
$refer=$_GET['refer'];
}
require_once $_SERVER['DOCUMENT_ROOT'].'/admin/config.php';
$sql='DELETE FROM token';
mysqli_query($link,$sql);
unlink("full_full.txt");
?>
<?php
$segment='full';
$a=file_get_contents('https://api.kite.trade/instruments');
file_put_contents($_SERVER['DOCUMENT_ROOT'].'/admin/'.strtolower($segment).'_full.txt', $a);
?>
<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
require_once $_SERVER['DOCUMENT_ROOT'].'/admin/config.php';
$insert_data="";
$insert=0;
$myFile=$_SERVER['DOCUMENT_ROOT'].'/admin/full_full.txt';
$lines = file($myFile);
$limit=(sizeof($lines));
$strt=1;
while($strt<$limit){
$insert=$strt+1;
$datas=$lines[$strt];
$s = explode (",", $datas);
$ss=json_encode($s);
$sss=json_decode($ss,true);
$instrument_token=$sss[0];
$exchange_token=$sss[1];
$tradingsymbol=$sss[2];
$name=$sss[3];
$name=trim($name,'"');
//$name=mysqli_real_escape_string($link,$name);
$name=clean($name);
$last_price=$sss[4];
$expiry=$sss[5];
if($expiry==''){
 $expiry=0;
}
$strike=$sss[6];
$tick_size=$sss[7];
$lot_size=$sss[8];
$instrument_type=$sss[9];
$segment=$sss[10];
$exchange=$sss[11];
$exchange=trim($exchange);
$expiry_timestamp=0;
if($expiry!=0){
if($exchange!='MCX'){
//$expiry_timestamp=strtotime($expiry)+36000;
$expiry_timestamp=strtotime($expiry)+55800;
}
if($exchange=='MCX'){
//$expiry_timestamp=strtotime($expiry)+64800;
$expiry_timestamp=strtotime($expiry)+84600;
}
}
$title='';
$title_hash='';
if($exchange==='BCD'){
$title=bcd_title_maker($name,$expiry,$strike,$instrument_type);
}
if($exchange==='BFO'){
$title=bfo_title_maker($name,$expiry,$strike,$instrument_type);
}
if($exchange==='BSE'){
$title=bse_title_maker($name,$tradingsymbol);
}
if($exchange==='CDS'){
$title=cds_title_maker($segment,$tradingsymbol,$name,$expiry,$strike,$instrument_type);
}
if($exchange==='MCX'){
$title=mcx_title_maker($name,$expiry,$strike,$instrument_type);
}

if($exchange==='NFO'){
$title=nfo_title_maker($name,$expiry,$strike,$instrument_type);
}
if($exchange==='NSE'){
$title=nse_title_maker($name,$tradingsymbol);
}
if($exchange==='NSEIX'){
$title=nseix_title_maker($name,$tradingsymbol);
}
$title_hash=md5($instrument_token.$exchange_token.'token');
//$title_hash=crc32($title.$instrument_token.$exchange_token);
//$title_hash=crc32($tradingsymbol.$segment.$exchange);
//$title_hash=crc32($instrument_token.$exchange_token);
//$title_hash=md5($instrument_token.$exchange_token);
//$title_hash=hash('sha256',$instrument_token.$exchange_token);
$raw="('$title','$title_hash','$instrument_token','$exchange_token','$tradingsymbol','$name','$last_price','$expiry','$strike','$tick_size','$lot_size','$instrument_type','$segment','$exchange','$expiry_timestamp'),";
$insert_data=$insert_data.$raw;
if($strt%500==0){
$sql="INSERT INTO `token`(`title`,`title_hash`,`instrument_token`, `exchange_token`, `tradingsymbol`, `name`, `last_price`, `expiry`,`strike`,`tick_size`, `lot_size`,`instrument_type`,`segment`,`exchange`,`expiry_timestamp`) VALUES ".$insert_data;
$sql=substr_replace($sql,"", -1);

if (!mysqli_query($link,$sql)){
echo("Error description: " . mysqli_error($link));
}
$insert_data="";
}
$strt++;
}
$sql="INSERT INTO `token`(`title`,`title_hash`,`instrument_token`, `exchange_token`, `tradingsymbol`, `name`, `last_price`, `expiry`,`strike`,`tick_size`, `lot_size`,`instrument_type`,`segment`,`exchange`,`expiry_timestamp`) VALUES ".$insert_data;
$sql=substr_replace($sql,"", -1);
if (!mysqli_query($link,$sql)){
echo("Error description: " . mysqli_error($link));
}

function bcd_title_maker($name,$expiry,$strike,$instrument_type){
$title=fut_opt($name,$expiry,$strike,$instrument_type);
return $title;
}


function bfo_title_maker($name,$expiry,$strike,$instrument_type){
$title=fut_opt($name,$expiry,$strike,$instrument_type);
return $title;
}


function bse_title_maker($name,$tradingsymbol){
$title=$name;
if($name==''){
$title=$tradingsymbol;
}
return $title;
}



function cds_title_maker($segment,$tradingsymbol,$name,$expiry,$strike,$instrument_type){
if($segment=='INDICES'){
$title=$name;
if($name==''){
$title=$tradingsymbol;
}
}
if($segment!='INDICES'){
$title=fut_opt($name,$expiry,$strike,$instrument_type);
}
return $title;
}

function mcx_title_maker($name,$expiry,$strike,$instrument_type){
$title=fut_opt($name,$expiry,$strike,$instrument_type);
return $title;
}

function nfo_title_maker($name,$expiry,$strike,$instrument_type){
$title=fut_opt($name,$expiry,$strike,$instrument_type);
return $title;
}



function nse_title_maker($name,$tradingsymbol){
$title=$name;
if($name==''){
$title=$tradingsymbol;
}
return $title;
}

function nseix_title_maker($name,$tradingsymbol){
$title=$name;
if($name==''){
$title=$tradingsymbol;
}
return $title;
}


function fut_opt($name,$expiry,$strike,$instrument_type){
$strike_output='';
if($strike!=0){
$strike_output=$strike.' ';
}
$title=$name.' '.expiry_to_human($expiry).' | '.$strike_output.$instrument_type;
return $title;
}

function expiry_to_human($expiry){
$timestamp = strtotime($expiry);
$new_date = date("d M Y", $timestamp);
$date=date('d', strtotime($new_date));
$month=date('M', strtotime($new_date));
$year=date('Y', strtotime($new_date));
$new_date=strtoupper($date.' '.$month.' '.$year);
return $new_date;
}





function clean0($string) {
   $string = str_replace(' ', '-', $string); // Replaces all spaces with hyphens.

   return preg_replace('/[^A-Za-z0-9\-]/', '', $string); // Removes special chars.
}

function clean($string) {
$string = str_replace(' ', '-', $string);
$string=preg_replace('/[^A-Za-z0-9\-]/', '', $string);
$string = str_replace('-', ' ', $string);
return $string;
}


?>
<?php
if($refer!=1){
echo('success');
}
if($refer==1){
echo "<script>location='index.php'</script>";
}
?>