<?php
require_once $_SERVER['DOCUMENT_ROOT'].'/apis/web.php';
send_notification('1689858587719060942','refrehsh');
?>