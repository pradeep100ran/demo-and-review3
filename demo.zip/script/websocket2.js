function itr(data,location,decimal,k){
if(k==undefined){
k=8;
}
var low=(location-1)*8;
var response=hexdec_to_dec(ittrate2(low,k,data));
var output=decii(response,decimal);
return output;
}

function fno_mode_ltpc_for_spot_watchlist(data){
var stock=itr(data,1);
var decimal=deci(stock);
var ltp=itr(data,2,decimal);
var close=itr(data,3,decimal);
var change=(ltp-close).toFixed(decimal);
var pchange=((change)*100/(close)).toFixed(2);
print_value_fno_mode_ltpc_for_spot(stock,ltp,close,change,pchange);
}
function fno_mode_ltpc(data){
var stock=itr(data,1);
var decimal=deci(stock);
var ltp=itr(data,2,decimal);
var close=itr(data,3,decimal);
var change=change_finder(ltp,close,decimal);
var pchange=((change)*100/(close)).toFixed(2);
print_value_fno_mode_ltpc(stock,ltp,close,change,pchange);
}

function change_finder(ltp,close,decimal){
var cdecimal=decimal;
if(cdecimal>=4){
  cdecimal=4;
}
var change=(ltp-close).toFixed(cdecimal);
return change;
}


function fno_mode_full_for_indices(data){
var stock=itr(data,1);
var decimal=deci(stock);
var ltp=itr(data,2,2);
var high=itr(data,3,2);
var low=itr(data,4,2);
var open=itr(data,5,2);
var close=itr(data,6,2);
var timestamp=itr(data,8);
var change=change_finder(ltp,close,decimal);
var pchange=((change)*100/(close)).toFixed(2);
print_value_fno_mode_full_for_indices(stock,ltp,open,high,low,close,change,pchange,timestamp);
}
function fno_mode_full(data){
var stock=itr(data,1);
var decimal=deci(stock);
var ltp=itr(data,2,decimal);
var ltq=itr(data,decimal);
var avg=itr(data,4,decimal);
var volume=itr(data,5);
var tbq=itr(data,6);
var tsq=itr(data,7);
var open=itr(data,8,decimal);
var high=itr(data,9,decimal);
var low=itr(data,10,decimal);
var close=itr(data,11,decimal);
var exchange_timestamp=itr(data,12);
var oi=itr(data,13);
var oi2=itr(data,14);
var exchange_timestamp1=itr(data,16);
if(exchange_timestamp1>exchange_timestamp){
 exchange_timestamp=exchange_timestamp1;
}
market_depth_five(stock,'buy',ittrate2(128,120,data));
market_depth_five(stock,'sell',ittrate2(248,120,data));
var change=change_finder(ltp,close,decimal);
var pchange=((change)*100/(close)).toFixed(2);
print_value_fno_mode_full(stock,ltp,ltq,avg,volume,tbq,tsq,open,high,low,close,change,pchange,exchange_timestamp,oi);
}

function market_depth_uuu(stock,type,data){
var start=0;
var lim=data.length;
var pattern=1;
while(start<lim){
var quantity=itr(data,1);
var price=itr(data,2,2);
var pr=itr(data,5,2);
print_buy_market_depth_five(stock,type,price,quantity,pattern);
start=start+24;
pattern=pattern+1;
}
}


function market_depth_five(stock,type,data){
var start=0;
var pattern=1;
while(start<5){
var quantity=itr(data,(3*start)+1);
var decimal=deci(stock);
var price=itr(data,(3*start)+2,decimal);
//var orders=itr(data,(3*start)+3);
print_buy_market_depth_five(stock,type,price,quantity,pattern);
start=start+1;
pattern=pattern+1;
}
}


function print_buy_market_depth_five(stock,type,price,quantity,pattern){
if(type=='buy'){
printer(stock+'mdbp'+pattern,price);
printer(stock+'mdbq'+pattern,quantity);
}
if(type=='sell'){
printer((stock+'mdsp'+pattern),price);
printer(stock+'mdsq'+pattern,quantity);
}
}
function fno_mode_ltpc_for_position(data){
var stock=itr(data,1);
var decimal=deci(stock);
var ltp=itr(data,2,decimal);
var close=itr(data,3,decimal);
var change=change_finder(ltp,close,decimal);
var pchange=((change)*100/(close)).toFixed(2);
print_value_fno_mode_ltpc_for_position(stock,ltp,close,change,pchange);
}