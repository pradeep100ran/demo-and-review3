function place_order_after_quantity_fill(vol){
old_volume=0;
required_quantity=0;
should_count_volume=0;
var order_data=hold_order;
var basket_id=order_data[0].basket_id;
var title=order_data[0].title;
var title_hash=order_data[0].title_hash;
var token=order_data[0].token;
var lot_size=order_data[0].lot_size;
var segment=order_data[0].segment;
var exchange=order_data[0]. exchange;
var price=order_data[0].price;
//var quantity=order_data[0]. quantity;
quantity=vol;
var type=order_data[0].type;
hold_order=[];

if(active_bottom_tab=='watchlist'){
fn_wl1801_order_window(title,title_hash,token,lot_size,segment,exchange);
}
if(active_bottom_tab=='position'){
fn_wl1901_order_window(title,title_hash,token,lot_size,segment,exchange);
}

var error_msg='';
if(quantity==0){
error_msg="<strong>ORDER CANCELLED</strong> <br>NO QUANTITY IS EXECUTED <br>AND  YOUR ORDER IS CANCELLED.";
}
if(quantity%lot_size!=0){
error_msg="<strong>PLEASE NOTE</strong><br>QUANTITY SHOUD BE IN THE MULTIPLE OF "+lot_size;
}
if(error_msg!=''){
small_notification('danger',error_msg);
}



if(quantity>=1){
send_order(basket_id,title_hash,price,quantity,type);
}
}



setInterval(function(){ 
var json=greeks_websocket_token;
var k=0;
while(k<json.length){
var instrument_token=(json[k]);
ittrate_greeks(instrument_token,0); 
k++;
}
},1000);
function greeks_printer(id,premium,delta,theta,gamma,vega,rho){
printer('greek_price'+id,'₹'+premium);
printer('greek_delta'+id,delta);
printer('greek_theta'+id,theta);
printer('greek_gamma'+id,gamma);
printer('greek_vega'+id,vega);
printer('greek_rho'+id,rho);
}

function greeks_calculator(id,type,spot,strike,int_rate,delta_t,volt){
var d1 = (Math.log(spot/strike) + (int_rate + Math.pow(volt,2)/2) * delta_t) / (volt*Math.sqrt(delta_t))
var d2 = (Math.log(spot/strike) + (int_rate - Math.pow(volt,2)/2) * delta_t) / (volt*Math.sqrt(delta_t));
var fv_strike = (strike)*Math.exp(-1*int_rate*delta_t);
var distribution = gaussian(0, 1);

if(type=='CE'){
var premium = (spot * distribution.cdf(d1) - fv_strike * distribution.cdf(d2)).toFixed(2);
var delta = (distribution.cdf(d1)).toFixed(4);
var gamma = (distribution.pdf(d1)/(spot*volt*Math.sqrt(delta_t))).toFixed(4);
var vega = (spot*distribution.pdf(d1)*Math.sqrt(delta_t)/100).toFixed(4);
var theta = ((-1*spot*distribution.pdf(d1)*volt/(2*Math.sqrt(delta_t)) - int_rate*fv_strike*distribution.cdf(d2))/365).toFixed(4);
var rho = (fv_strike*delta_t*distribution.cdf(d2)/100).toFixed(4);
}
if(type=='PE'){
var premium = (fv_strike * distribution.cdf(-1*d2) - spot * distribution.cdf(-1*d1)).toFixed(2);
var theta = ((-1*spot*distribution.pdf(d1)*volt/(2*Math.sqrt(delta_t)) + int_rate*fv_strike*distribution.cdf(-1*d2))/365).toFixed(4);
var delta = (distribution.cdf(d1)-1).toFixed(4);
var rho =(-1*fv_strike*delta_t*distribution.cdf(-1*d2)/100).toFixed(4);
var gamma =(distribution.pdf(d1)/(spot*volt*Math.sqrt(delta_t))).toFixed(4);
;
var vega =(spot*distribution.pdf(d1)*Math.sqrt(delta_t)/100).toFixed(4);
}

greeks_printer(id,premium,delta,theta,gamma,vega,rho);
}



function ittrate_greeks(id,ltp){
var spot=ids('ltp'+id+'spot');
if(spot!=null){
spot=spot.innerHTML;
}
var vix=ids('ltp'+id+'vix');
if(vix!=null){
vix=vix.innerHTML;
}
var type=ids('instrument_type'+id);
if(type!=null){
type=type.innerHTML;
}
var strike=ids('strike'+id);
if(strike!=null){
strike=strike.innerHTML;
}
var int_rate =7.419;
var div_yld = 0;
var date_expiry=ids('expiry_timestamp'+id);
if(date_expiry!=null){
date_expiry=date_expiry.innerHTML;
}
var date_now =Math.floor(new Date()/1000)+19800;
var seconds = Math.floor(date_expiry - (date_now));
if(seconds<=0){
    seconds=1;
}
var delta_t =((seconds)/(24*60*60))/365.0;
delta_t =((seconds)/(24*60*60))/365.0;
volt = vix/100;
int_rate = int_rate/100;
if(id!=null&&type!=null&&spot!=null&&strike!=null&&int_rate!=null&&delta_t!=null&&volt!=null){
greeks_calculator(id,type,spot,strike,int_rate,delta_t,volt);
}
}






function print_vix_and_spot(id,ltp,change,pchange){
if(id==264969){
var a=random(1,10);
if(a>5){
  change=pchange+'%';
}
var list = document.getElementsByClassName('vixltpo');
for (n=0;n<list.length;++n) {
list[n].innerHTML=ltp;
}
var list = document.getElementsByClassName('vixltp');
for (n=0;n<list.length;++n) {
list[n].innerHTML='VIX = '+ltp+'('+change+')';
}
}
if(id!=264969){
var lis = document.getElementsByClassName('ltp'+id+'spoto');
for (k=0;k<lis.length;++k) {
lis[k].innerHTML=ltp;
}
var lis = document.getElementsByClassName('ltp'+id+'spot');
var a=random(1,10);
if(a>5){
  change=pchange+'%';
}
for (k=0;k<lis.length;++k) {
lis[k].innerHTML='SPOT = '+ltp+'('+change+')';
}
}
}
function print_value_fno_mode_ltpc(id,ltp,close,change,pchange){
if(spotvix_websocket_token.includes(id)){
print_vix_and_spot(id,ltp,change,pchange);
}
ltp_id=id+'ltp';
ltp_value='0';
change_id=id+'ltp_change';
change_value='<span class='+"ltpchange"+'>₹'+change+'('+pchange+'%)</span>'
if(change==0){
ltp_value='<span class='+"ltp_roundb"+'>₹'+ltp+'</span>';
}
if(change>0){
ltp_value='<span class='+"ltp_roundg"+'>₹'+ltp+'</span>';
}
if(change<0){
ltp_value='<span class='+"ltp_roundr"+'>₹'+ltp+'</span>';
}
printer(ltp_id,ltp_value);
printer(change_id,change_value);
}
function order_manager(id,ltp){
document.getElementById(id+'price').value=ltp;
var q=document.getElementById(id+'quantity').value;
if(q==null){
    q=0;
}
var value=round(q*ltp);
document.getElementById(id+'value').value=value;
}

function volume_counter(token,volume){
volume_updated_time=Math.floor(Date.now()/1000);
if(should_count_volume==1){
if(old_volume==0){
 old_volume=volume;
}
var volume_difference=volume-old_volume;
if(volume_difference>=required_quantity){
place_order_after_quantity_fill(required_quantity);
volume_difference=required_quantity;
should_count_volume=0;
required_quantity=0;
old_volume=0;
}
printer('executed_quantity',volume_difference);
}
}


function order_manager2(id,ltp,volume,change,p_change){
volume_counter(id,volume);
var p=document.getElementById(id+'price');
if(p!=null){
document.getElementById(id+'price').value=ltp;
printer(id+'ltpt1','₹'+ltp);
var q=document.getElementById(id+'quantity').value;
if(q==null){
    q=0;
}
var decimal=deci(id);
//var value=round(q*ltp,decimal);
var value=deciii(q*ltp,decimal);
document.getElementById(id+'value').value=value;
printer(id+'changeltpt','<strong>₹<span id="'+id+'ltpooo">'+change+'</span>(<span id="'+id+'ltpoooo">'+p_change+'</span>%)</strong>');
}
}
function print_value_fno_mode_full_for_indices(id,ltp,open,high,low,close,change,pchange,exchange_timestamp){
printer(id+'change1','<strong>₹'+change+'('+pchange+'%)</strong>');
printer(id+'ltp1','<strong>₹'+ltp+'</strong>');
printer('open'+id,'<strong>OPEN = ₹'+open+'</strong>');
printer('high'+id,'<strong>HIGH = ₹'+high+'</strong>');
printer('low'+id,'<strong>LOW =₹'+low+'</strong>');
printer('close'+id,'<strong>P.CLOSE = ₹'+close+'</strong>');
exchange_timestamp=exchange_timestamp*1000;
var dt=new Date(exchange_timestamp);
var tim=(time_to_human(dt));
printer('exchange_timestamp'+id,'<strong>UPDATED = '+tim+'</strong>');
}
function print_value_fno_mode_full(id,ltp,ltq,avg,volume,tbq,tsq,open,high,low,close,change,pchange,exchange_timestamp,oi){
order_manager2(id,ltp,volume,change,pchange);
if(greeks_websocket_token.includes(id)){
ittrate_greeks(id,ltp);
}
var n=["OPEN","HIGH","LOW","P.CLOSE","AVG. PRICE","VOLUME","UPDATED","OI"];
var p=function (k){
 return k+' = ₹'; 
}
var o=function (k){
 return k+' = '; 
}
printer(id+'change1','₹<span id="'+id+'ltpooo">'+change+'</span>(<span id="'+id+'ltpoooo">'+pchange+'</span>%)');
printer(id+'ltp1','<strong>₹<span id="'+id+'ltpoo">'+ltp+'</span></strong>');
printer('open'+id,p(n[0])+open);
printer('high'+id,p(n[1])+high);
printer('low'+id,p(n[2])+low);
printer('close'+id,p(n[3])+close);
printer('avg_price'+id,p(n[4])+avg);
printer('volume'+id,o(n[5])+indian(volume));
printer(id+'tbq',tbq);
printer(id+'tsq',tsq);
exchange_timestamp=exchange_timestamp*1000;
var dt=new Date(exchange_timestamp);
var tim=(time_to_human(dt));
printer('exchange_timestamp'+id,o(n[6])+tim);
printer('oi'+id,o(n[7])+indian(oi));
}
function isjson(str) {
try{
 JSON.parse(str);
    } catch (e) {
        return 0;
    }
    return 1;
}
function lcl_ucl(data){
var n=["LCL","UCL"];
var p=function (k){
 return k+' = ₹'; 
}
var possible=(isjson(data));
if(possible==1){
let json=JSON.parse(data);
var type=(json['type']);
if(type=='quote'){
var id=(json['id']);
var jjj=(json['data'][0]);
var lcl=Object.values(jjj)[0];
var ucl=Object.values(jjj)[1];
var decimal=deci(id);
lcl=deciii(lcl,decimal);
ucl=deciii(ucl,decimal);
printer('lcl'+id,p(n[0])+lcl);
printer('ucl'+id,p(n[1])+ucl);
}
}
}
function random(min, max) {
return Math.floor(Math.random() * (max - min) ) + min;
}
function print_value_fno_mode_ltpc_for_position(id,ltp,close,change,pchange){
if(id==256265||id==260105||id==264969){
print_value_fno_mode_ltpc_for_position_index(id,ltp,close,change,pchange);
}
else{
print_value_fno_mode_ltpc_for_position_stock(id,ltp,close,change,pchange);
}
}
function print_value_fno_mode_ltpc_for_position_index(id,ltp,close,change,pchange){
if(change==0){
var span_id='p701';
}
if(change>0){
var span_id='p702';
}
if(change<0){
var span_id='p703';
}
var a=random(1,10);
if(a<=8){
ltp=ltp+'('+change+')';
}
if(a>8){
ltp=ltp+'('+pchange+'%)';
}
printer('position'+id+'ltp','<span class="'+span_id+'">'+ltp+'</span>');
}
function print_value_fno_mode_ltpc_for_position_stock(id,ltp,close,change,pchange){
if(change==0){
pclass='p707';
ltpclass='p731';
}
if(change>0){
pclass='p708';
ltpclass='p732';
}
if(change<0){
pclass='p709';
ltpclass='p733';
}
//printer('position'+id+'ltp','LTP <span class=p719>₹'+ltp+'</span>');
printer('position'+id+'ltp','LTP <span class='+ltpclass+'>'+ltp+'</span>');
printer('position'+id+'ltpchange','<span class='+""+'>'+change+'('+pchange+'%)</span>');
var price=0;
var pricee=ids('position'+id+'price');
if(pricee!=null){
price=pricee.innerHTML;
}
var quantity=0;
var quantityy=ids('position'+id+'quantity');
if(quantityy!=null){
quantity=quantityy.innerHTML;
}
open_position_wise_pl(id,ltp,price,quantity);
}
function open_position_wise_pl(id,ltp,price,quantity){
var decimal=deci(id);
var diff=round((ltp-price),decimal);
var pl=deciii(diff*quantity,decimal);
//alert(raw_pl);
//var pl=round((ltp-price,decimal)*quantity);
if(pl==0){
pclass='p707';
}
if(pl>0){
pclass='p708';
}
if(pl<0){
pclass='p709';
}
printer('position'+id+'pl','P/L <span class='+pclass+'><span class="pnl_pnl">'+indian(pl)+'</span></span>');
total_pnls();
}
function total_pnls(){
var pl=0;
const x= document.querySelectorAll(".pnl_pnl");
var i=0;
var j =x.length;
while(i<j){
var value=x[i].innerHTML;
var nv=value.replace(/[^\d.-]/g, '');
//alert(nv);
//pl=pl+parseFloat(nv,10);
pl=parseFloat(pl)+parseFloat(nv);
i++;
}
print_total_pnls(pl);
}
function print_total_pnls(value){
iclass='total_pnl_bazing'
if(value==0){
pclass='p711';
}
if(value>0){
pclass='p712';
}
if(value<0){
pclass='p713';
}
printer('tpnl','<span class="'+iclass+'">Total P&L</span><br><span class="'+pclass+'">₹'+indian(round(value))+'</span>');
}