function fn500_login_main(){
a=fn501_login_root();
printer('main',a);
hider('lg570');
hider('lg575');
}




function fn501_login_root(){
var a='<div class="lg580"><div class="lg581_left" onclick="fn500_login_main()">LOGIN</div><div class="lg581_right" onclick="fn300_register_main()">REGISTER</div></div><div class="lg570" id="lg570"></div><div id="lg560" class="lg560"><div class="lg561">NUMBER</div><div class="lg561"><input type="number" pattern="[0-9]{2} [0-9]{3} [0-9]{2} [0-9]{3}" id="lg561_number" class="lg561_number" required></div><div class="lg561">PASSWORD</div><div class="lg561"><input id="lg561_password" class="lg561_password"></div><div id="lg561_submit" class="lg561"><button type="button" onclick="lg502_login_validator()" class="lg561_submit">SUBMIT</button></div><div id="lg575" class="lg575"><div class="lg575_inner"></div></div></div>';
return a;
}












function lg502_login_validator(){
hider('lg570');
var number=document.getElementById("lg561_number").value;
if(number.length!==10){
shower('lg570');
var title='Alert';
var info='Number length should be 10 digit';
var alert_class='danger';
fn570_login_notification_printer(title,info,alert_class);
return;
}
var password=document.getElementById("lg561_password").value;
if(password.length<6){
shower('lg570');
var title='Alert';
var info='Password length should be more then 6 character';
var alert_class='danger';
fn570_login_notification_printer(title,info,alert_class);
return;
}
if(number!==null&& number!== '' && password!==null&&password!==''){
lg502_login_server_wait_loader();
lg503_login_server_request(number,password);
}
}

function lg502_login_server_wait_loader(){
hider('lg561_submit');
shower('lg575');
}




function lg503_login_server_request(number,password){
var response =0;
let xhr = new XMLHttpRequest();
xhr.open("GET", "/apis/user_login.php?number="+number+"&password="+password);
response=xhr.responseText;
xhr.onreadystatechange = function () {
   if (xhr.readyState === 4) {
var response=(xhr.responseText);
fn504_login_server_response(response);
   }};
xhr.send();
}




function fn504_login_server_response(response){
shower('lg561_submit');
hider('lg575');
fn504_login_notification_from_response(response);
}




function fn504_login_notification_from_response(response){
let json=JSON.parse(response);
var response_code=(json.response_code);
var response_status=(json.response_status);
if(response_status=='success'){
var data=(json.data[0]);
fn505_login_success(data);
}
if(response_status=='failed'){
title='Alert   ';
if(response_code=='401'){
info='Number is not registered';
alert_class='danger';
}
if(response_code=='402'){
alert_class='info';
info='Wrong Password';
}
fn570_login_notification_printer(title,info,alert_class);
}
}


function fn505_login_success(data){
var userid=data.userid;
var name=data.name;
var number=data.number;
var email=data.email;
var login_hash=data.login_hash;
put_local('login_status','1');
put_local('userid',userid);
put_local('name',name);
put_local('number',number);
put_local('email',email);
put_local('login_hash',login_hash);
application();
}




function fn570_login_notification_close(){
hider('lg570');
}
function fn570_login_notification_printer(title,info,alert_class){
shower('lg570');
var data='<div><div class="alert alert-'+alert_class+'"><div onclick="fn570_login_notification_close()" class="lg570_close_button">&#x2716;</div><strong>'+title+'</strong> '+info+'</div></div>';
printer('lg570',data);
}