function fn300_register_main(){
a=fn301_register_root();
printer('main',a);
hider('rg370');
hider('rg375');
}




function fn301_register_root(){
var a='<div class="rg380"><div class="rg381_left" onclick="fn500_login_main()">LOGIN</div><div class="rg381_right" onclick="fn300_register_main()">REGISTER</div></div><div class="rg370" id="rg370"></div><div class="rg360"><div class="rg362"><div class="rg362_left">NAME</div><div class="rg362_right"><input id="rg362_name" class="rg362_name"></div></div><div class="rg362"><div class="rg362_left">NUMBER</div><div class="rg362_right"><input id="rg362_number" class="rg362_number"></div></div><div class="rg362"><div class="rg362_left">EMAIL</div><div class="rg362_right"><input id="rg362_email" class="rg362_email"></div></div><div class="rg362"><div class="rg362_left">PASSWORD</div><div class="rg362_right"><input id="rg362_password" class="rg362_password"></div></div></div><div id="rg363_submit" class="rg363"><button type="button" onclick="rg302_register_validator()" class="rg363_submit">SUBMIT</button></div><div id="rg375" class="rg375"><div class="rg375_inner"></div></div>';
return a;
}

function rg302_register_validator(){
hider('rg370');

var name=document.getElementById("rg362_name").value;
if(name.length<3){
var title='Alert';
var info='Name length should be 3 character long';
var alert_class='danger';
fn370_register_notification_printer(title,info,alert_class);
return;
}
if (name.match(/^\d/)) {
var title='Alert';
var info='Name cannot start with number';
var alert_class='danger';
fn370_register_notification_printer(title,info,alert_class);
return;
}


var number=document.getElementById("rg362_number").value;

if(number.length!==10){
var title='Alert';
var info='Number length should be 10 digit';
var alert_class='danger';
fn370_register_notification_printer(title,info,alert_class);
return;
}


var email=document.getElementById("rg362_email").value;
if(email.length<5){
var title='Alert';
var info='Email Address is not valid';
var alert_class='danger';
fn370_register_notification_printer(title,info,alert_class);
return;
}

var password=document.getElementById("rg362_password").value;
if(password.length<6){
var title='Alert';
var info='Password length should be more then 6 character';
var alert_class='danger';
fn370_register_notification_printer(title,info,alert_class);
return;
}
if(name!==null && name!=='' && number!==null && number!==''&& email!==null && email!=='' && password!==null && password!==''){
fn302_register_server_wait_loader();
fn303_register_server_request(name,number,email,password);
}
}

function fn302_register_server_wait_loader(){
hider('rg363_submit');
shower('rg375');
hider('rg370');
}




function fn303_register_server_request(name,number,email,password){
var response =0;
let xhr = new XMLHttpRequest();
xhr.open("GET", "/apis/user_register.php?name="+name+"&number="+number+"&email="+email+"&password="+password);
response=xhr.responseText;
xhr.onreadystatechange = function () {
   if (xhr.readyState === 4) {
var response=(xhr.responseText);
fn304_register_server_response(response);
   }};
xhr.send();
}




function fn304_register_server_response(response){
shower('rg363_submit');
hider('rg375');
fn304_register_notification_from_response(response);
}




function fn304_register_notification_from_response(response){
let json=JSON.parse(response);
var response_code=(json.response_code);
var response_status=(json.response_status);
if(response_status=='success'){
var data=(json.data[0]);
fn305_register_success(data);
}
if(response_status=='failed'){
title='Alert   ';
if(response_code=='401'){
info='Number is not registered';
alert_class='danger';
}
if(response_code=='402'){
alert_class='info';
info='This Number is Already Registered';
}
fn370_register_notification_printer(title,info,alert_class);
}
}


function fn305_register_success(data){
var title='Congrulations ';
var alert_class='success';
var info='Your Registration is successful.';
fn370_register_notification_printer(title,info,alert_class);
}




function fn370_register_notification_close(){
hider('rg370');
}
function fn370_register_notification_printer(title,info,alert_class){
shower('rg370');
var data='<div><div class="alert alert-'+alert_class+'"><div onclick="fn370_register_notification_close()" class="rg370_close_button">&#x2716;</div><strong>'+title+'</strong> '+info+'</div></div>';
printer('rg370',data);
}