function hex(arrayBuffer) {
  const buff = new Uint8Array(arrayBuffer);
  return Array.from(buff, (byte) => byte.toString(16).padStart(2, "0")).join("");
}
function hexdec_to_dec(data) {
  return parseInt(data, 16);
}

function ittrate2(start,limit,data){
result=data.slice(start,start+limit);
return result;
}





function ittrate(data){
var data=hex(data);
data=data.slice(4);
var start=0;
var stop=data.length;
while(start<stop){
var stock_len=hexdec_to_dec(ittrate2(start+0,4,data));
var bits=stock_len*2;
var forward=(ittrate2(start+4,bits,data));
if(active_bottom_tab=='position'){
fno_mode_ltpc_for_position(forward);
};
if(active_bottom_tab=='watchlist'){
fno_mode_ltpc(forward);
}
start=start+((stock_len)*2)+4;
}
}

function ittrate_full(data){
lcl_ucl(data);
var data=hex(data);
data=data.slice(4);
//alert(data);
var start=0;
var stop=data.length;
while(start<stop){
var stock_len=hexdec_to_dec(ittrate2(start+0,4,data));
//alert(stock_len);
var bits=stock_len*2;
var forward=(ittrate2(start+4,bits,data));

//alert(bits);
if(bits==64){
//alert(forward);
fno_mode_full_for_indices(forward);
}
if(bits==24){
//alert('here');
fno_mode_ltpc_for_spot_watchlist(forward);
}
if(bits==368){
fno_mode_full(forward);
}
start=start+((stock_len)*2)+4;
}
}






function websocket_root(){
var linked_broker_name=get_local('linked_broker_name');
if(linked_broker_name==null||linked_broker_name==0){
  return;
}
var kite_enctoken_time=get_local('kite_enctoken_time');
var current_time=Date.now();
var time_passed=current_time-kite_enctoken_time;
if(time_passed>80000000){
var link_type=get_local('kite_link_type');
if(link_type!='long'){
put_local('broker_linked_status','0');
return;
}
if(link_type=='long'){
put_local('broker_linked_status','0');
fn_auto_totp();
return;
}
}
websocket_root2();
}




function websocket_root2(){
var kite_enc_new_token=get_local('kite_enctoken');
if(kite_enc_new_token==null||kite_enc_new_token==0){
  return;
}
var url="wss://ws.zerodha.com/?user_id=USERID&enctoken="+kite_enc_new_token;

var local_url="wss://flawless-valley-harbor.glitch.me";


socket_local=new WebSocket(local_url);
socket_mini=new WebSocket(url);
socket_full=new WebSocket(url);

socket_mini.binaryType = "arraybuffer";
socket_full.binaryType = "arraybuffer";


socket_local.onopen = function(e) {
var userid=get_local('userid');
socket_local.send('{"userid":"'+userid+'"}');
};

socket_local.onmessage = function(event) {
var k=(event.data);

if(k=='refresh'){
location.reload();
return;
}

show_notification(k);

//small_notification('success',k);
//navigator.vibrate([100,50,100,50]);
//audio.play();
};



socket_mini.onmessage = function(event) {
ittrate(event.data);
};
socket_mini.onerror=function(event){
};
socket_mini.onclose=function (cl){
mini_websocket_status=0;
if(mini_websocket_status!=1){
setTimeout(function() {
var lbn=get_local('linked_broker_name');
websocket_root2();
}, 5000);
}
};
socket_mini.onopen = function(e) {
mini_websocket_status=1;
if(mini_websocket_token.length>=1){
smart_websocket_subscribe('mini','subscribe',mini_websocket_token);
}
if(spotvix_websocket_token.length>=1){
smart_websocket_subscribe('mini','subscribe',spotvix_websocket_token);
}
};
socket_full.onopen = function(k) {
full_websocket_status=1;
if(full_websocket_token.length>=1){
smart_websocket_subscribe('full','subscribe',full_websocket_token);
}
};


socket_full.onclose=function (cl){
full_websocket_status=0;
};


socket_full.onmessage = function(event) {
ittrate_full(event.data);
};
}






function smart_websocket_subscribe(socket_type,action,token){
if(token==null){
return;
}
if(token.length==0){
return;
}
var type=(typeof token);
if(type=='number'){
var temp_array=[];
var temp_token=parseInt(token);
temp_array.push(temp_token);
token=temp_array;
}
var msg='';
var unique= Array.from(new Set(token));
if(socket_type=='mini'){
if(mini_websocket_status==1){
if(action=='subscribe'){
active_mini_token=Array.from(new Set(active_mini_token.concat(unique)));
msg='{"a":"mode","v":["ltpc",['+unique+']]}';
}
if(action=='unsubscribe'){
active_mini_token=active_mini_token.filter( function( el ) {
  return !unique.includes(el);
} );
msg='{"a":"unsubscribe","v":['+unique+']}';
}
if(msg!=null){
socket_mini.send(msg);
}
}
}
if(socket_type=='full'){
if(full_websocket_status==1){
if(action=='subscribe'){
active_full_token=Array.from(new Set(active_full_token.concat(unique)));
msg='{"a":"mode","v":["full",['+unique+']]}';
for (var i = 0; i <unique.length; i++) {
var xx=unique[i];
socket_full.send('{"id":"'+xx+'","a":"quote","v":{"fields":["lower_circuit_limit","upper_circuit_limit","expiry"],"tokens":['+xx+']}}');
}
}
if(action=='unsubscribe'){
active_full_token=active_full_token.filter( function( el ) {
  return !unique.includes(el);
} );
msg='{"a":"unsubscribe","v":['+unique+']}';
}
if(msg!=null){
socket_full.send(msg);
}
}
}
}